<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('profile_image')->nullable()->after('email');
            $table->string('full_name')->after('profile_image');
            $table->string('subscription_plan')->default('rookie')->after('full_name');
            $table->enum('account_status', ['active', 'inactive', 'suspended'])->default('active')->after('subscription_plan');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['profile_image', 'full_name', 'subscription_plan', 'account_status']);
        });
    }
};
