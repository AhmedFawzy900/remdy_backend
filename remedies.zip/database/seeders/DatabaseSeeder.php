<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        // Call AdminSeeder
        $this->call([
            // AdminSeeder::class,
            // BodySystemSeeder::class,
            // RemedyTypeSeeder::class,
            // RemedySeeder::class,
            // UserSeeder::class,
            // InstructorSeeder::class,
            // ArticleSeeder::class,
            // CourseSeeder::class,
            // VideoSeeder::class,
            // DiseaseSeeder::class,
            // FaqSeeder::class,
            // PolicySeeder::class,
            // AboutSeeder::class,
            // ReviewSeeder::class,
            // ContactUsSeeder::class,
            // NotificationSeeder::class,
            // PlanSeeder::class,
            // AdSeeder::class,
            LessonSeeder::class,
            LessonContentBlockSeeder::class,
            CoursePurchaseSeeder::class,
            LessonProgressSeeder::class,
        ]);
    }
}
